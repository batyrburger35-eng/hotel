import java.util.Locale;
import java.util.Scanner;

public class HotelManagementSystem {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Информация о гостинице
        String hotelName = "Отель Элеон";
        String hotelAddress = "ул. Абая, 10";
        String hotelPhone = "+7 700 123 45 67";
        int totalRooms = 50;
        int availableRooms = 12;
        float hotelRating = 4.7f;
        char hotelCategory = 'A';
        boolean isOpen = true;

        // Информация о клиенте
        String clientName = "Иван Иванов";
        int clientAge = 25;
        String clientPassport = "TEST123456";
        String clientPhone = "+7 701 111 22 33";
        double clientBalance = 25000.00;
        boolean isRegistered = true;

        // Информация о номере
        int roomNumber = 305;
        String roomType = "Deluxe";
        double roomPrice = 18000.00;
        int roomFloor = 3;
        boolean hasWiFi = true;
        int bedCount = 2;
        char roomStatus = 'F';

        // Данные бронирования
        long bookingId = 1000001L;

        System.out.print("Введите количество дней проживания: ");
        int daysOfStay = scanner.nextInt();

        if (daysOfStay <= 0) {
            System.out.println("Количество дней должно быть больше нуля.");
            scanner.close();
            return;
        }

        System.out.print("Введите сумму внесённой оплаты: ");
        double paymentAmount = scanner.nextDouble();

        if (paymentAmount < 0) {
            System.out.println("Сумма оплаты не может быть отрицательной.");
            scanner.close();
            return;
        }

        double fullPrice = roomPrice * daysOfStay;
        double discount = 10.0;
        double discountAmount = fullPrice * discount / 100;
        double finalPrice = fullPrice - discountAmount;
        double debt = Math.max(0, finalPrice - paymentAmount);

        boolean bookingConfirmed =
                isOpen && isRegistered && availableRooms > 0 && roomStatus == 'F';

        String bookingStatus;
        if (bookingConfirmed) {
            bookingStatus = "Подтверждено";
            availableRooms--;
            roomStatus = 'B';
        } else {
            bookingStatus = "Не подтверждено";
        }

        // Вывод информации о гостинице
        System.out.println("\n=== Информация о гостинице ===");
        System.out.println("Название: " + hotelName);
        System.out.println("Адрес: " + hotelAddress);
        System.out.println("Телефон: " + hotelPhone);
        System.out.println("Всего номеров: " + totalRooms);
        System.out.println("Свободных номеров: " + availableRooms);
        System.out.println("Рейтинг: " + hotelRating);
        System.out.println("Категория: " + hotelCategory);
        System.out.println("Гостиница работает: " + isOpen);

        // Вывод анкеты клиента
        System.out.println("\n=== Анкета клиента ===");
        System.out.println("ФИО: " + clientName);
        System.out.println("Возраст: " + clientAge);
        System.out.println("Номер документа: " + clientPassport);
        System.out.println("Телефон: " + clientPhone);
        System.out.printf(Locale.US, "Баланс: %.2f%n", clientBalance);
        System.out.println("Зарегистрирован: " + isRegistered);

        // Итоговый отчёт
        System.out.println("\n=== Отчёт о бронировании ===");
        System.out.println("Номер бронирования: " + bookingId);
        System.out.println("Гостиница: " + hotelName);
        System.out.println("Клиент: " + clientName);
        System.out.println("Номер комнаты: " + roomNumber);
        System.out.println("Тип номера: " + roomType);
        System.out.println("Этаж: " + roomFloor);
        System.out.println("Количество кроватей: " + bedCount);
        System.out.println("Wi-Fi: " + hasWiFi);
        System.out.println("Дней проживания: " + daysOfStay);
        System.out.printf(Locale.US, "Стоимость за сутки: %.2f%n", roomPrice);
        System.out.printf(Locale.US, "Стоимость без скидки: %.2f%n", fullPrice);
        System.out.printf(Locale.US, "Скидка: %.1f%%%n", discount);
        System.out.printf(Locale.US, "Сумма скидки: %.2f%n", discountAmount);
        System.out.printf(Locale.US, "Итоговая стоимость: %.2f%n", finalPrice);
        System.out.printf(Locale.US, "Внесённая оплата: %.2f%n", paymentAmount);
        System.out.printf(Locale.US, "Остаток задолженности: %.2f%n", debt);
        System.out.println("Статус бронирования: " + bookingStatus);

        scanner.close();
    }
}